#!/bin/sh

docker build . -t latest/vsp_cache
