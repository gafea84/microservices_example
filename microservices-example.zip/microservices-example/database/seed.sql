-- This seeds mock data for offenders map

START TRANSACTION;

-- TODO

COMMIT;
