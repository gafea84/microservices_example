-- Dev container startup script
CREATE USER vsp WITH SUPERUSER LOGIN PASSWORD 'password';
CREATE DATABASE vsp;
