#!/bin/sh

# Run Migrations
# TODO

