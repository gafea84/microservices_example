#!/bin/sh

docker rm vsp_database
