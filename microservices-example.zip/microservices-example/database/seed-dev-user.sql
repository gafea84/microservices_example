-- This script sets up a dev tenant/team/user for development purposes only.

START TRANSACTION;

-- TODO

COMMIT;
