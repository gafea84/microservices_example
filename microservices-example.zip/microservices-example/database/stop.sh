#!/bin/sh

docker stop vsp_database
