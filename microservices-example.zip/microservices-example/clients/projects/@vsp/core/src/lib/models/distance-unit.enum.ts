export enum DistanceUnit {
  Miles = 'Miles',
  Kilometers = 'Kilometers'
}
