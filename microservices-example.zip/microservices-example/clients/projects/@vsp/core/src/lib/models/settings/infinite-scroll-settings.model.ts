export interface InfiniteScrollSettings {
  throttle: number,
  scrollUpDistance: number,
  scrollDownDistance: number,
}
