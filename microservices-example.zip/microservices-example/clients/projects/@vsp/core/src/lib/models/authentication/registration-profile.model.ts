export interface RegistrationProfile {
  firstName: string,
  lastName: string
}
