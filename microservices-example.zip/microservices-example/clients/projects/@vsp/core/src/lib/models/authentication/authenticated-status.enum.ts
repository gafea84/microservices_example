export enum AuthenticatedStatus {
  AUTHENTICATED = 'authenticated',
  NOT_AUTHENTICATED = 'not authenticated'
};
