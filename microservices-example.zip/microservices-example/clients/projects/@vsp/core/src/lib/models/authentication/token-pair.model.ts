export interface TokenPair {
  accessToken: string,
  refreshToken: string
}
