export enum PersonSex {
  MALE = 'Male',
  FEMALE = 'Female'
}
