export const adminClientIdentifier = '02f60adf-dbe0-4db1-af00-3ff5a7404a31';
export const publicClientIdentifier = '793d84f7-40f7-4917-99b4-0240e387d048';
