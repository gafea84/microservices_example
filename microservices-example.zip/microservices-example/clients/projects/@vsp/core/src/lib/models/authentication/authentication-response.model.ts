import { AuthenticatedUser } from './authenticated-user.model';

export interface AuthenticationResponse {
  authenticatedUser: AuthenticatedUser;
}
