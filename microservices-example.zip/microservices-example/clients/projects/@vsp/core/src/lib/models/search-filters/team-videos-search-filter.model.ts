export interface TeamVideosSearchFilter {
  searchKeywords?: string,
  startDate?: Date | null,
  endDate?: Date | null
}
