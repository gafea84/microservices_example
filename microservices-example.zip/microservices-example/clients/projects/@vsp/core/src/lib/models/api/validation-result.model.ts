export interface ValidationResult {
  isValid: boolean;
}
