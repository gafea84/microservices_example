export interface TeamAnnouncementsSearchFilter {
  searchKeywords?: string,
  startDate?: Date | null,
  endDate?: Date | null
}
