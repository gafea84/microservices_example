export enum ChatState {
  CONNECTED = 'connected',
  DISCONNECTED = 'disconnected'
}
