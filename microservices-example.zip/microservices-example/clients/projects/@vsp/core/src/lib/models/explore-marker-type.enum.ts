export enum ExploreMarkerType {
  OFFENDERS = 'offenders',
  MISSING = 'missing'
}
