export enum MediaVisibility {
  Public = 'public',
  Private = 'private',
  Hidden = 'hidden'
}
