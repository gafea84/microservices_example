import { UserAccountDto } from './user.dto';

export interface UserSettings {
  userDetails: UserAccountDto
}
