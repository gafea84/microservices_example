export enum SortDirection {
  Ascend = 'Ascend',
  Descend = 'Descend'
}
