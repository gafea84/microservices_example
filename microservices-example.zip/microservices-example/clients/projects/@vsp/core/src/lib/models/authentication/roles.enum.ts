export enum Roles {
  Root = 'ROOT',
  Admin = 'ADMIN',
  User = 'USER'
}
