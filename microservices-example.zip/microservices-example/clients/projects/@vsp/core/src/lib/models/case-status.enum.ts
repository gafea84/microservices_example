export enum CaseStatus {
  New = 'new',
  Investigating = 'investigating',
  Open = 'open',
  Closed = 'closed'
}
