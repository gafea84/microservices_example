export enum MeasurementUnit {
  CENTIMETERS = 'Centimeters',
  INCHES = 'Inches'
}
