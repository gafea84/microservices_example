export enum DataLayoutStyle {
  Grid = 'grid',
  List = 'list',
}
