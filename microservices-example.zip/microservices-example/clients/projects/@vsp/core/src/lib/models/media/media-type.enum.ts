export enum MediaType {
  Video = 'video',
  Audio = 'audio',
  Image = 'image',
  Document = 'document'
}
