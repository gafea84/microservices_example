export interface CasesSearchFilter {
  searchKeywords?: string,
  startDate?: Date | null,
  endDate?: Date | null
}
