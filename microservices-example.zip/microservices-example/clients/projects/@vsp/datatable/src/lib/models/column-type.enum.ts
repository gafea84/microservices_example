export enum ColumnType {
  TEXT,
  TEXT_TRUNCATED,
  EMAIL,
  IMAGE,
  DATE,
  DATE_TIME,
  CURRENCY,
  TITLE,
}
