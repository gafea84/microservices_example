export interface BasicQuerySearchFilter {
  query?: string | null | undefined,
  isDeleted?: boolean | null | undefined
};
