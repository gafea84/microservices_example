import { AutoFocusControlDirective } from './auto-focus-control.directive';

describe('AutoFocusControlDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoFocusControlDirective();
    expect(directive).toBeTruthy();
  });
});
