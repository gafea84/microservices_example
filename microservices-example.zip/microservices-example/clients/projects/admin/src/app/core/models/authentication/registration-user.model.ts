export interface RegistrationUser {
  userName: string,
  password: string,
  confirmPassword: string
}
