export interface RegistrationProfile {
  firstName: string,
  lastname: string
}
