export interface PasswordReset {
  email: string,
  client: string,
}
