export interface ListOption {
  id?: string,
  label: string,
  value: string
}
