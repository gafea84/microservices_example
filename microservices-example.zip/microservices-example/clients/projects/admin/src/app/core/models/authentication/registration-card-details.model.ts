export interface RegistrationCardDetails {
  isValid: boolean,
  brand: string,
  token: string,
  lastFour: string,
}
