export interface RegistrationPlan {
  id: string
}
