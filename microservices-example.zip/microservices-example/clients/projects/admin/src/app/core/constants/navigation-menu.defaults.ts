export const isCollapsedByDefault: boolean = true;
