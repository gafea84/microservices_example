export interface RegistrationCompany {
  name: string
}
