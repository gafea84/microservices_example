export class CacheKeys {
  public static AUTHENTICATED_USER = 'authenticated_user';
}
