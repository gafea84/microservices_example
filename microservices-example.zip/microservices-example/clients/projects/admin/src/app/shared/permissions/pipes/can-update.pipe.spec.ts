import { VspCanUpdatePipe } from './can-update.pipe';

describe('VspCanUpdatePipe', () => {
  it('create an instance', () => {
    const pipe = new VspCanUpdatePipe();
    expect(pipe).toBeTruthy();
  });
});
