import { VspHasModulePermissionPipe } from './has-module-permission.pipe';

describe('VspHasModulePermissionPipe', () => {
  it('create an instance', () => {
    const pipe = new VspHasModulePermissionPipe();
    expect(pipe).toBeTruthy();
  });
});
