import { VspCanCreatePipe } from './can-create.pipe';

describe('VspCanCreatePipe', () => {
  it('create an instance', () => {
    const pipe = new VspCanCreatePipe();
    expect(pipe).toBeTruthy();
  });
});
