import { VspCanReadPipe } from './can-read.pipe';

describe('VspCanReadPipe', () => {
  it('create an instance', () => {
    const pipe = new VspCanReadPipe();
    expect(pipe).toBeTruthy();
  });
});
