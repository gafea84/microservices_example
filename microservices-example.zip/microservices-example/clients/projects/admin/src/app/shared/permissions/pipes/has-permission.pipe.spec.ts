import { VspHasPermissionPipe } from './has-permission.pipe';

describe('VspHasPermissionPipe', () => {
  it('create an instance', () => {
    const pipe = new VspHasPermissionPipe();
    expect(pipe).toBeTruthy();
  });
});
