import { VspCanDeletePipe } from './can-delete.pipe';

describe('VspCanDeletePipe', () => {
  it('create an instance', () => {
    const pipe = new VspCanDeletePipe();
    expect(pipe).toBeTruthy();
  });
});
