import { RpcExceptionFilter } from './rpc-exception.filter';

describe('RpcExceptionFilter', () => {
  it('should be defined', () => {
    expect(new RpcExceptionFilter()).toBeDefined();
  });
});
